let countdown;
function startCountdown(){
    clearInterval(countdown);
    const targetDate = new Date(document.getElementById("datetime").value);
  if(isNaN(targetDate.getTime())){
    alert("please select a valid date and time");
    return;
  }
  countdown = setInterval(() => {
    const now = new Date();
    const diff = targetDate - now;
    if (diff <=0){
        clearInterval(countdown);
        document.getElementById("timer").innerHTML = "Time's up!";
        return;
    }
    const years = Math.floor(diff/(1000 * 60 * 60 * 24 * 365));
    const months = Math.floor((diff % (1000 * 60 * 60 * 24 * 365)) / (1000 * 60 * 60 * 24 * 30));
    const days = Math.floor((diff % (1000 * 60 * 60 * 24 * 30)) / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    document.getElementById("timer").innerHTML = `${years} Years ${months} Months ${days} Days ${hours}:${minutes}:${seconds}`;

  },1000);
}